# default.py
addon_id="script.icechannel.extn.channel.4.on.youtube"
addon_name="Channel 4 on Youtube"
